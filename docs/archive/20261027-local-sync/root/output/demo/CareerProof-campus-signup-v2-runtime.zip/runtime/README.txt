Local synthetic execution observations collected outside CareerProof.
Original business source is unchanged. No independent review or authorship certification.
HTTP responses and pytest output describe the recorded local environment only.
