"""Synthetic Redis cache example; not executed and no contributor attribution."""
import redis


def cache_course(client: redis.Redis, course_id: int, value: str, ttl_seconds: int = 60):
    if ttl_seconds <= 0:
        raise ValueError("ttl_seconds must be positive")
    key = f"course:{course_id}"
    client.setex(key, ttl_seconds, value)
    return client.get(key)
